<?php
  
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Lang" content="en">
<meta name="author" content="">
<meta http-equiv="Reply-to" content="@.com">
<meta name="generator" content="PhpED 6.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="creation-date" content="06/01/2011">
<meta name="revisit-after" content="15 days">
<title>Untitled</title>
<script type="text/javascript" src="/Scripts/jquery-1.6.2.js"></script>
<script type="text/javascript" src="/Scripts/Stubby/jquery.stubbyautolist.js"></script>
<link rel="stylesheet" type="text/css" href="/Styles/stubbylist.css">
</head>
<body>     
<!-- element that will display the selected items -->
<div id="stubby-display" class="clearfix"></div>
<br /><br />

<!-- input that will display the auto-complete -->
<input type="text" id="stubbyInput" class="stubbyList1"/>

<!-- stubby list item template -->  
<div class="stubby-list-item-template">
    <div class="topicListItem clearfix">
        <div class="list-item-left stubbyList1">
            <img stubby-data="ProfileImage" stubby-image-path="/Images/" alt="Profile Image" width="40px" />
        </div>
        <div class="list-item-right stubbyList1">
            <span stubby-data="FirstName"></span>&nbsp;<span stubby-data="LastName"></span><br /> 
            <span stubby-data="UserName"></span>
        </div>
    </div>
</div>

<!-- stubby display item template -->
<div class="stubby-display-item-template">
    <div class="my-display-container clearfix">
        <div class="display-item-left">
                <img stubby-image-path="/Images/" stubby-data="ProfileImage" alt="Profile Image" width="20px" />
        </div>
        <div class="display-item-right"> 
            <span stubby-data="UserName"></span>
            <a class="element-button" stubby-delete-button="true">x</a>
        </div>
    </div>
</div>
                                                                      
<script type="text/javascript">
    $("#stubbyInput").stubbyautolist({
        ajaxUrl: '/getJsonData.php',
        keyValue: 'UserName',
        focusClass: 'stubbyList1'
    });
</script>
</body>
</html>