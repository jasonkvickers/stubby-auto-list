<?php
  // Get the posted value
  $term = $_GET['term'];
  $searchKey = $_GET['searchKey'];

  // array - this could be populated from a db result set
  $json = array(
    array('Id' => 1, 'FirstName' => 'Jason', 'LastName '=> 'Vickers', 'UserName' => 'jvickers', 'ProfileImage' => 'default-user.png'),
    array('Id' => 2, 'FirstName' => 'Marc', 'LastName' => 'Rasmussen', 'UserName' => 'mrasmussen', 'ProfileImage' => 'default-user.png'),
    array('Id' => 3, 'FirstName' => 'Ted', 'LastName' => 'Pfiefer', 'UserName' => 'tpfiefer', 'ProfileImage' => 'default-user.png'),
    array('Id' => 4, 'FirstName' => 'Frank', 'LastName' => 'Galarraga', 'UserName' => 'fgalarraga', 'ProfileImage' => 'default-user.png'),
    array('Id' => 5, 'FirstName' => 'Eddie', 'LastName' => 'Munster', 'UserName' => 'emunster', 'ProfileImage' => 'default-user.png'),
    array('Id' => 6, 'FirstName' => 'Jan', 'LastName' => 'Brady', 'UserName' => 'jbrady', 'ProfileImage' => 'default-user.png')
  );
  
  // search array for term - in this case, I am going to match username
  $filteredJson = array();
  
  $obj = new ArrayObject($json);
  $i = $obj->getIterator();
  
  while($i->valid()) {
      $current = $i->current();
      if(strpos($current[$searchKey], $term) > -1)
      {
          $filteredJson[$i->key()] = $i->current();
      }
      
      $i->next();
  }  
  
  echo json_encode(array('stubbyData' => $filteredJson));
?>
