﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Stubby.Data;

namespace Stubby.Controllers
{
    public class HomeController : Controller
    {
        private AppContext db = new AppContext();

        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult StubbyList()
        {
            return View();
        }

        public ActionResult GetAJAX(string term, string searchKey)
        {
            var results = new List<TestPerson>
                {
                    new TestPerson {Id = 1, FirstName = "Jason", LastName = "Vickers", UserName = "jvickers", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 2, FirstName = "Marc", LastName = "Rasmussen", UserName = "mrasmussen", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 3, FirstName = "Ted", LastName = "Pfeifer", UserName = "tpfeifer", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 4, FirstName = "Frank", LastName = "Galarraga", UserName = "fgalarraga", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 5, FirstName = "Eddie", LastName = "Munster", UserName = "emunster", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 6, FirstName = "Jan", LastName = "Brady", UserName = "jbrady", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 7, FirstName = "Fester", LastName = "Adams", UserName = "fadams", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 8, FirstName = "Tonya", LastName = "Harding", UserName = "tharding", ProfileImage = "default-user.png"},
                    new TestPerson {Id = 9, FirstName = "Steve", LastName = "Jones", UserName = "sjones", ProfileImage = "default-user.png"}
                };

            var stubbyData = results.Where(r => r.GetType().GetProperty(searchKey).GetValue(r, null).ToString().Contains(term));
            return Json(new { stubbyData }, JsonRequestBehavior.AllowGet);
        }

    }

    public class TestPerson
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public string ProfileImage { get; set; }
    }
}
