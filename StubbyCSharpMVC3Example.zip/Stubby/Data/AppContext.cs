﻿using System.Data.Entity;

namespace Stubby.Data
{
    public class AppContext : DbContext
    {
        public AppContext() : base("name=DefaultConnection") { }
        
        ////Display Entities
        //public DbSet<Content> Contents { get; set; }
        //public DbSet<Article> Articles { get; set; }
        //public DbSet<ArticleVersion> ArticleVersions { get; set; }
        //public DbSet<PageVersion> PageVersions { get; set; }
        //public DbSet<Question> Questions { get; set; }
        //public DbSet<FlaggedContent> FlaggedContents { get; set; }
        //public DbSet<Rating> Ratings { get; set; }
        //public DbSet<IndividualRating> IndividualRatings { get; set; }
        //public DbSet<Topic> Topics { get; set; }
        //public DbSet<ArticleType> ArticleTypes { get; set; }
        //public DbSet<ContentMember> ContentMembers { get; set; } 

        ////Pet Entities
        //public DbSet<Pet> Pets { get; set; }
        //public DbSet<PetBreed> PetBreeds { get; set; }
        //public DbSet<PetType> PetTypes { get; set; } 

        //public DbSet<Page> Pages { get; set; }

        //// Profile Entities (not handled by Membership)
        //public DbSet<ProfileConnection> ProfileConnections { get; set; }
    }
}